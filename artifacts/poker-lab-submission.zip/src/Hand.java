import java.util.*;

/**
 * A poker hand is a list of cards, which can be of some "kind" (pair, straight, etc.)
 * 
 */
public class Hand implements Comparable<Hand> {

    public enum Kind {HIGH_CARD, PAIR, TWO_PAIR, THREE_OF_A_KIND, STRAIGHT, 
        FLUSH, FULL_HOUSE, FOUR_OF_A_KIND, STRAIGHT_FLUSH}

    private final List<Card> cards;

    /**
     * Create a hand from a string containing all cards (e,g, "5C TD AH QS 2D")
     */
    public Hand(String c) {
        cards = new ArrayList<Card>();

        String[] cardStrings = c.split(" ");

        for (String cardString : cardStrings) {
            cards.add(new Card(cardString));
        }
    }
    /**
     * @returns true if the hand has n cards of the same rank
	 * e.g., "TD TC TH 7C 7D" returns True for n=2 and n=3, and False for n=1 and n=4
     */
    protected boolean hasNKind(int n) {
        for (Card card : cards) {
            int count = 0;

            for (Card otherCard : cards) {
                if (card.getRank() == otherCard.getRank()) {
                    count++;
                }
            }

            if (count == n) {
                return true;
            }
        }

        return false;
    }
    
    /**
	 * Optional: you may skip this one. If so, just make it return False
     * @returns true if the hand has two pairs
     */
    public boolean isTwoPair() {
        int pairCount = 0;

        for (Card card : cards) {
            int count = 0;
            for (Card otherCard : cards) {
                if (card.getRank() == otherCard.getRank()) {
                    count++;
                }
            }

            // Count each rank only once, even though it occurs on two cards.
            if (count == 2) {
                boolean rankAlreadyCounted = false;
                for (Card previousCard : cards) {
                    if (previousCard == card) {
                        break;
                    }
                    if (previousCard.getRank() == card.getRank()) {
                        rankAlreadyCounted = true;
                        break;
                    }
                }
                if (!rankAlreadyCounted) {
                    pairCount++;
                }
            }
        }

        return pairCount == 2;
    }
    
    /**
     * @returns true if the hand is a straight 
     */
    public boolean isStraight() {
        List<Integer> ranks = new ArrayList<>();

        for (Card card : cards) {
            ranks.add(card.getRank().ordinal());
        }

        Collections.sort(ranks);

        if (ranks.get(0) == Card.Rank.DEUCE.ordinal()
                && ranks.get(1) == Card.Rank.THREE.ordinal()
                && ranks.get(2) == Card.Rank.FOUR.ordinal()
                && ranks.get(3) == Card.Rank.FIVE.ordinal()
                && ranks.get(4) == Card.Rank.ACE.ordinal()) {
            return true;
        }

        for (int i = 0; i < ranks.size() - 1; i++) {
            if (ranks.get(i + 1) != ranks.get(i) + 1) {
                return false;
            }
        }

        return true;

    }
    
    /**
     * @returns true if the hand is a flush
     */
    public boolean isFlush() {

        Card.Suit firstCardSuit = cards.get(0).getSuit();

        for (Card card : cards){
            if (card.getSuit() != firstCardSuit){
                return false;
            }
        }
        return true;
    }
    
    @Override
    public int compareTo(Hand h) {
        //hint: delegate!
		//and don't worry about breaking ties
        return this.kind().compareTo(h.kind());
    }
    
    /**
	 * This method is already implemented and could be useful! 
     * @returns the "kind" of the hand: flush, full house, etc.
     */
    public Kind kind() {
        if (isStraight() && isFlush()) return Kind.STRAIGHT_FLUSH;
        else if (hasNKind(4)) return Kind.FOUR_OF_A_KIND; 
        else if (hasNKind(3) && hasNKind(2)) return Kind.FULL_HOUSE;
        else if (isFlush()) return Kind.FLUSH;
        else if (isStraight()) return Kind.STRAIGHT;
        else if (hasNKind(3)) return Kind.THREE_OF_A_KIND;
        else if (isTwoPair()) return Kind.TWO_PAIR;
        else if (hasNKind(2)) return Kind.PAIR; 
        else return Kind.HIGH_CARD;
    }

}
